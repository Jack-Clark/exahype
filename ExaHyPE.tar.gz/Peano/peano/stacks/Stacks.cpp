#include "peano/stacks/Stacks.h"

const int peano::stacks::Constants::InOutStack  = -1;
