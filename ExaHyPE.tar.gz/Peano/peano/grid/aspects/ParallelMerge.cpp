#include "peano/grid/aspects/ParallelMerge.h"


tarch::logging::Log  peano::grid::aspects::ParallelMerge::_log( "peano::grid::aspects::ParallelMerge" );
